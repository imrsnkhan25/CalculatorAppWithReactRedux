import React, { Component } from "react";
import { connect } from "react-redux";
import "./CalculatorApp.css";
class Calculator extends Component {
  constructor(props) {
    super(props);
    this.state = {
      args: [],
      arr: [],
      a: "",
      b: "",
      counter: Number(""),
      action: "",
      clickCount: Number("1"),
      disp: Number("")
    };
  }

  render() {
    return (
      <div>
        {/* <span className="heading">Calculator App</span> */}
        <div className="container">
          <div className="display">
            <label id="value"></label>
            {this.state.disp > 0 ? (
              <p id="value1"></p>
            ) : (
              <p id="value1">{this.props.result}</p>
            )}
          </div>
          <div className="display1"></div>
          <div className="buttons">
            <button
              id="btn"
              onClick={e => {
                this.setState({
                  a: (this.state.a = ""),
                  b: (this.state.b = ""),
                  action: (this.state.action = ""),
                  arr: (this.state.arr = []),
                  args: (this.state.args = []),
                  counter: (this.state.counter = 0)
                });
                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                if (this.state.args.length === 0) {
                  document.getElementById("value1").innerHTML = 0;
                }
              }}
            >
              {" "}
              C
            </button>
            &nbsp; &nbsp;
            <button
              id="btn"
              value="-"
              onClick={e => {
                var clickCount = this.state.clickCount++;
                console.log(clickCount);
                if (clickCount % 2 !== 0) {
                  if (this.state.counter === 0) {
                    if (this.state.arr.length === 0) {
                      this.state.arr.push(e.target.value);
                      this.setState({ a: this.state.arr.join("") });
                      this.state.args.push(e.target.value);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    } else {
                      this.setState({ a: this.state.a * -1 });
                      this.state.args.splice(0, 0, "-");
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    }
                  } else {
                    if (this.state.arr.length === 0) {
                      this.state.arr.push(e.target.value);
                      this.setState({ b: this.state.arr.join("") });
                      this.state.args.push(e.target.value);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    } else {
                      this.setState({ b: this.state.b * -1 });
                      this.state.args.splice(0, 0, "-");
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    }
                  }
                } else {
                  if (this.state.counter === 0) {
                    if (this.state.arr.length === 0) {
                      this.state.arr.splice(0, 1);
                      this.setState({ a: this.state.arr.join("") });
                      this.state.args.push(0, 1);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    } else {
                      this.setState({ a: this.state.a * 1 });
                      this.state.args.splice(0, 1);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    }
                  } else {
                    if (this.state.arr.length === 0) {
                      this.state.arr.push(e.target.value);
                      this.setState({ b: this.state.arr.join("") });
                      this.state.args.push(e.target.value);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    } else {
                      this.setState({ b: this.state.b * 1 });
                      this.state.args.splice(0, 1);
                      document.getElementById(
                        "value"
                      ).innerHTML = this.state.args.join("");
                    }
                  }
                }
              }}
            >
              <sup>+</sup>/-
            </button>
            &nbsp;&nbsp;
            <button
              id="btn"
              value="%"
              onClick={e => {
                this.setState({ counter: this.state.counter + 1 });
                this.state.arr.length = 0;
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                var act = e.target.value;
                this.setState({ action: act });
              }}
            >
              {" "}
              %
            </button>
            &nbsp;&nbsp;
            <button
              id="btn1"
              value="/"
              onClick={e => {
                this.setState({ counter: this.state.counter + 1 });
                this.state.arr.length = 0;
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                var act = e.target.value;
                this.setState({ action: act });
              }}
            >
              {" "}
              /
            </button>
          </div>
          <div className="buttons">
            <button
              id="btn"
              value="7"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  //   alert(this.state.a);
                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;
                  //   alert(this.state.b);
                  console.log("b:" + this.state.b);
                }
              }}
            >
              7
            </button>
            &nbsp; &nbsp;
            <button
              id="btn"
              value="8"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              8
            </button>
            &nbsp;&nbsp;
            <button
              id="btn"
              value="9"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              9
            </button>
            &nbsp;&nbsp;
            <button
              id="btn1"
              value="x"
              onClick={e => {
                this.setState({ counter: this.state.counter + 1 });
                this.state.arr.length = 0;
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                var act = e.target.value;
                this.setState({ action: act });
              }}
            >
              x
            </button>
          </div>
          <div className="buttons">
            <button
              id="btn"
              value="4"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = e.target.value;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              4
            </button>
            &nbsp; &nbsp;
            <button
              id="btn"
              value="5"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
                console.log(num);
              }}
            >
              5
            </button>
            &nbsp;&nbsp;
            <button
              id="btn"
              value="6"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              6
            </button>
            &nbsp;&nbsp;
            <button
              id="btn1"
              value="-"
              onClick={e => {
                this.setState({ counter: this.state.counter + 1 });
                this.state.arr.length = 0;
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                var act = e.target.value;
                this.setState({ action: act });
              }}
            >
              -
            </button>
          </div>
          <div className="buttons">
            <button
              id="btn"
              value={1}
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              {" "}
              1
            </button>
            &nbsp; &nbsp;
            <button
              id="btn"
              value={2}
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              {" "}
              2
            </button>
            &nbsp;&nbsp;
            <button
              id="btn"
              value={3}
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");

                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              {" "}
              3
            </button>
            &nbsp;&nbsp;
            <button
              id="btn1"
              value="+"
              onClick={e => {
                this.setState({ counter: this.state.counter + 1 });
                this.state.arr.length = 0;
                this.state.args.push(e.target.value);

                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                var act = e.target.value;
                this.setState({ action: act });
              }}
            >
              +
            </button>
          </div>
          <div className="buttons1">
            <button
              id="btn"
              value={0}
              onClick={e => {
                this.setState({ disp: (this.state.disp = 1) });
                this.state.arr.push(e.target.value);
                console.log(this.state.arr);
                var num = this.state.arr.join("");
                this.state.args.push(e.target.value);
                document.getElementById(
                  "value"
                ).innerHTML = this.state.args.join("");
                if (this.state.counter === 0) {
                  this.state.a = num;
                  this.state.b = "";

                  console.log("a:" + this.state.a);
                } else {
                  this.state.b = num;

                  console.log("b:" + this.state.b);
                }
              }}
            >
              {" "}
              0
            </button>
            &nbsp; &nbsp;
            <button
              id="btn"
              value="."
              onClick={e => {
                if (this.state.arr.length === 0) {
                  alert("wrong pattern");
                } else {
                  this.state.arr.push(e.target.value);
                  console.log(this.state.arr);
                  var num = this.state.arr.join("");
                  this.state.args.push(e.target.value);

                  document.getElementById(
                    "value"
                  ).innerHTML = this.state.args.join("");
                  if (this.state.counter === 0) {
                    this.state.a = num;
                    this.state.b = "";

                    console.log("a:" + this.state.a);
                  } else {
                    this.state.b = num;
                    console.log("b:" + this.state.b);
                  }
                }
              }}
            >
              {" "}
              .
            </button>
            &nbsp;&nbsp;
            <button
              id="btn2"
              onClick={e => {
                this.setState({ disp: (this.state.disp = 0) });
                this.props.fun1(this.state.a, this.state.b, this.state.action);
              }}
            >
              {" "}
              =
            </button>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    var1: state.a,
    var2: state.b,
    result: state.result
  };
};
const mapDispachToProps = dispach => {
  return {
    fun1: (a, b, action) =>
      dispach({ type: "fun1", first: a, second: b, op: action }),
    fun2: () => dispach({ type: "fun2" })
  };
};

export default connect(mapStateToProps, mapDispachToProps)(Calculator);
