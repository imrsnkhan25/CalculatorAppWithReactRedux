const initialState = {
  a: 0,
  b: 0,
  result: 0
};
const reducer = (state = initialState, action) => {
  const newState = { ...state };

  if (action.type === "fun1") {
    var result = 0;

    switch (action.op) {
      case "+":
        result = Number(action.first) + Number(action.second);

        break;
      case "-":
        result = Number(action.first) - Number(action.second);
        break;
      case "/":
        result = Number(action.first) / Number(action.second);
        break;
      case "%":
        result = Number(action.first) * (Number(action.second) / 100);
        break;
      case "x":
        result = Number(action.first) * Number(action.second);
        break;
      case "%":
        break;
      //   case "c":
      //     break;
      //   case "=":
      //     break;

      default:
        break;
    }
    newState.result = result;
  }

  return newState;
};
export default reducer;
